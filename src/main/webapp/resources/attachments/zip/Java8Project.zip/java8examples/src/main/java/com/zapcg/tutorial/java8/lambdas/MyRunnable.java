package com.zapcg.tutorial.java8.lambdas;
// An entirely different class (should be in a separate file)
	class MyRunnable implements Runnable {

		@Override
		public void run() {
			System.out.println("MyRunnable class : Hello World!\n");
		}

	}
