package generics.basic;

public class BlackAndWhiteCartridge {

	@Override
	public String toString() {
		return "balck and white";
	}

}
