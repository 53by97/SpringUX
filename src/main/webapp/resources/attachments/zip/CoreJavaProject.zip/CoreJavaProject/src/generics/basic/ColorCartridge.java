package generics.basic;

public class ColorCartridge {

	@Override
	public String toString() {
		return "color";
	}

}
