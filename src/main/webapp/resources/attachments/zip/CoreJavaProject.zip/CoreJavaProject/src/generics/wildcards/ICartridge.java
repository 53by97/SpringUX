package generics.wildcards;

public interface ICartridge {

	public int getFillPercentage();

}
