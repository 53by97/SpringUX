package enumerations.advanced;

public interface IColors {

	public abstract int getFillPercentage();
}
