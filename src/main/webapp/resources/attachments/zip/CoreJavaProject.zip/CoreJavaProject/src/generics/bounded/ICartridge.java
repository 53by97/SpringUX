package generics.bounded;

public interface ICartridge {

	public abstract int getFillPercentage();

}
