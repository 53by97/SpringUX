package enumerations.basic;

public enum ColorEnum {
	RED, BLUE, GREEN;
}
