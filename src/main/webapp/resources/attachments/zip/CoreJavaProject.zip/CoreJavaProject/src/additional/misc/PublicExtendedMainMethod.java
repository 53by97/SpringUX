package additional.misc;

class HavingMain {
	public static void main(String[] args) {
		System.out.println("Inside HavingMain's main() !");
	}
}

public class PublicExtendedMainMethod extends HavingMain {
	/*public static void main(String[] args) {
		System.out.println("Inside Actual main() !");
	}*/
}
